import SwiftUI
import UserNotifications 
import UIKit
import PhotosUI
import CoreML
import Vision
import CoreMotion
import MapKit
import CoreLocation
import ARKit
import SceneKit
import MessageUI

struct ContentView: View {
    @StateObject private var waypointStore = WaypointStore()
    @StateObject private var locationManager = LocationManager()
    
    var body: some View {
        TabView {
            HomeScreen()
                .tabItem {
                    Label("Safety", systemImage: "figure.hiking")
                }
                .environmentObject(waypointStore)
                .environmentObject(locationManager)
            AIFirstAidScreen()
                .tabItem {
                    Label("AI First Aid", systemImage: "cross.case.fill")
                }
            MapWayfinderScreen()
                .environmentObject(locationManager)
                            .onAppear {
                                // Print to console to see the exact state
                                print("Location Status Code: \(locationManager.authorizationStatus.rawValue)")
                                locationManager.requestPermission()
                            }
                .tabItem {
                    Label("Map", systemImage: "map.fill")
                }
                .environmentObject(waypointStore)
                .environmentObject(locationManager)
            EmergencyContactsScreen()
                .tabItem {
                    Label("Contacts", systemImage: "person.2.fill")
                }
                .environmentObject(waypointStore)
                .environmentObject(locationManager)
        }
    }
}

// MARK: - Sensor Manager (Real CoreMotion accelerometer + fall detection)
// Used only on main (motion queue + timers); @unchecked Sendable silences closure capture warnings.
final class SensorManager: ObservableObject, @unchecked Sendable {
    @Published var accelerationX: Double = 0
    @Published var accelerationY: Double = 0
    @Published var accelerationZ: Double = 0
    @Published var isMonitoring: Bool = false
    @Published var fallDetected: Bool = false
    @Published var showCountdown: Bool = false
    @Published var countdown: Int = 10
    @Published var showInactivityAlarm: Bool = false
    @Published var inactivitySeconds: Int = 0
    let inactivityThresholdSeconds: Int = 30
    @Published var alarmPulse: Bool = false
    
    private let motionManager = CMMotionManager()
    private let fallMagnitudeThreshold: Double = 2.5   // g's – large spike suggests impact/fall
    private let updateInterval: TimeInterval = 0.1    // 10 Hz
    private var countdownTimer: Timer?
    private var inactivityTimer: Timer?
    private var lastMagnitude: Double = 1.0
    
    /// Called immediately when a fall is detected; use to e.g. save current location.
    var onFallDetected: (() -> Void)?
    /// Called when inactivity alarm triggers; use to e.g. send emergency SMS.
    var onInactivityAlarm: (() -> Void)?
    
    func startMonitoring() {
        isMonitoring = true
        fallDetected = false
        showCountdown = false
        countdown = 10
        showInactivityAlarm = false
        inactivitySeconds = 0
        lastMagnitude = 1.0
        
        motionManager.accelerometerUpdateInterval = updateInterval
        guard motionManager.isAccelerometerAvailable else { return }
        
        motionManager.startAccelerometerUpdates(to: .main) { [weak self] data, _ in
            guard let self, let data = data, !self.fallDetected, !self.showInactivityAlarm else { return }
            let x = data.acceleration.x
            let y = data.acceleration.y
            let z = data.acceleration.z
            self.accelerationX = x
            self.accelerationY = y
            self.accelerationZ = z
            
            let magnitude = sqrt(x * x + y * y + z * z)
            if magnitude >= self.fallMagnitudeThreshold {
                self.triggerFall()
            }
            self.lastMagnitude = magnitude
        }
        
        inactivityTimer?.invalidate()
        inactivityTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self else { return }
            self.inactivitySeconds += 1
            if self.inactivitySeconds >= self.inactivityThresholdSeconds && !self.showInactivityAlarm && !self.showCountdown {
                self.showInactivityAlarm = true
                self.startAlarmPulse()
                self.onInactivityAlarm?()
            }
        }
    }
    
    func stopMonitoring() {
        isMonitoring = false
        motionManager.stopAccelerometerUpdates()
        countdownTimer?.invalidate()
        inactivityTimer?.invalidate()
        countdownTimer = nil
        inactivityTimer = nil
    }
    
    private func triggerFall() {
        guard !fallDetected else { return }
        fallDetected = true
        showCountdown = true
        countdown = 10
        onFallDetected?()
        countdownTimer?.invalidate()
        countdownTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] t in
            guard let self else { t.invalidate(); return }
            if self.countdown > 0 {
                self.countdown -= 1
            } else {
                t.invalidate()
                self.showCountdown = false
            }
        }
    }
    
    func userCheckedIn() {
        showInactivityAlarm = false
        inactivitySeconds = 0
        alarmPulse = false
    }
    
    func manualTriggerSOS() {
        showInactivityAlarm = false
        alarmPulse = false
        fallDetected = true
        showCountdown = true
        countdown = 10
        onFallDetected?()
        countdownTimer?.invalidate()
        countdownTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] t in
            guard let self else { t.invalidate(); return }
            if self.countdown > 0 {
                self.countdown -= 1
            } else {
                t.invalidate()
                self.showCountdown = false
            }
        }
    }
    
    private func startAlarmPulse() {
        alarmPulse = true
    }
}

// MARK: - HomeScreen (iPad-optimized with horizontal layout)
struct HomeScreen: View {
    @StateObject private var sensorManager = SensorManager()
    @EnvironmentObject private var waypointStore: WaypointStore
    @EnvironmentObject private var locationManager: LocationManager
    @Environment(\.horizontalSizeClass) private var hSizeClass
    
    var body: some View {
        ZStack {
            ScrollView {
                VStack(spacing: 20) {
                    headerSection
                    
                    if hSizeClass == .regular {
                        HStack(alignment: .top, spacing: 24) {
                            mainStatusColumn
                                .frame(maxWidth: .infinity)
                            InfoCard()
                                .frame(maxWidth: .infinity)
                        }
                    } else {
                        VStack(spacing: 16) {
                            mainStatusColumn
                            InfoCard()
                        }
                    }
                }
                .padding(.horizontal, hSizeClass == .regular ? 32 : 16)
                .padding(.bottom, 40)
                .frame(maxWidth: .infinity)
            }
            
            if sensorManager.showCountdown {
                SOSCountdownView(countdown: sensorManager.countdown)
            }
            
            if sensorManager.showInactivityAlarm && !sensorManager.showCountdown {
                InactivityAlarmView(
                    seconds: sensorManager.inactivitySeconds,
                    thresholdSeconds: sensorManager.inactivityThresholdSeconds,
                    pulse: sensorManager.alarmPulse,
                    onImOk: { sensorManager.userCheckedIn() },
                    onTriggerSOS: { sensorManager.manualTriggerSOS() }
                )
            }
        }
        .background {
            Image("mountainBackground")
                .resizable()
                .scaledToFill()
                .overlay(Color.black.opacity(0.35))
                .ignoresSafeArea()
        }
        .onAppear {
            sensorManager.onFallDetected = {
                saveFallLocation(waypointStore: waypointStore, locationManager: locationManager)
                sendEmergencySMS(reason: "Fall detected", locationManager: locationManager)
            }
            sensorManager.onInactivityAlarm = {
                sendEmergencySMS(reason: "No movement detected", locationManager: locationManager)
            }
            locationManager.requestPermission()
            locationManager.startUpdating()
            sensorManager.startMonitoring()
        }
        .onDisappear { sensorManager.stopMonitoring() }
    }
    
    // MARK: - Sub-Views
    
    private var headerSection: some View {
        VStack(spacing: 8) {
            Image(systemName: "figure.hiking")
                .font(.system(size: 36))
                .foregroundStyle(LinearGradient(colors: [.white, .green], startPoint: .top, endPoint: .bottom))
            Text("Hiking Safety")
                .font(.system(size: 28, weight: .bold, design: .rounded))
                .foregroundColor(.white)
        }
        .padding(.top, 40)
    }
    
    private var mainStatusColumn: some View {
        VStack(spacing: 16) {
            StatusCard(
                isMonitoring: sensorManager.isMonitoring,
                fallDetected: sensorManager.fallDetected,
                inactivityDetected: sensorManager.showInactivityAlarm
            )
            sensorDashboard
        }
    }
    
    private var sensorDashboard: some View {
        VStack(spacing: 14) {
            HStack {
                Image(systemName: "sensor.tag.radiowaves.forward")
                    .font(.system(size: hSizeClass == .regular ? 20 : 18))
                    .foregroundColor(.blue)
                Text("Live Sensor Dashboard")
                    .font(.system(size: hSizeClass == .regular ? 18 : 16, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                Spacer()
                Text("100ms")
                    .font(.system(size: hSizeClass == .regular ? 12 : 11, weight: .semibold, design: .monospaced))
                    .foregroundColor(.white.opacity(0.7))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Capsule().fill(.white.opacity(0.08)))
            }
            
            if hSizeClass == .regular {
                // iPad: horizontal sensor cards
                HStack(spacing: 16) {
                    SensorReadingCard(icon: "arrow.left.and.right", label: "X-Axis", value: sensorManager.accelerationX, color: .blue)
                        .accessibilityLabel("X-axis acceleration \(String(format: "%.3f", sensorManager.accelerationX))")
                    SensorReadingCard(icon: "arrow.up.and.down", label: "Y-Axis", value: sensorManager.accelerationY, color: .green)
                        .accessibilityLabel("Y-axis acceleration \(String(format: "%.3f", sensorManager.accelerationY))")
                    SensorReadingCard(icon: "arrow.up.and.down.and.arrow.left.and.right", label: "Z-Axis", value: sensorManager.accelerationZ, color: .orange)
                        .accessibilityLabel("Z-axis acceleration \(String(format: "%.3f", sensorManager.accelerationZ))")
                }
                .accessibilityElement(children: .contain)
                .accessibilityLabel("Live accelerometer data: X, Y, Z axes")
            } else {
                // iPhone: vertical sensor cards
                VStack(spacing: 12) {
                    SensorReadingCard(icon: "arrow.left.and.right", label: "X-Axis", value: sensorManager.accelerationX, color: .blue)
                        .accessibilityLabel("X-axis acceleration \(String(format: "%.3f", sensorManager.accelerationX))")
                    SensorReadingCard(icon: "arrow.up.and.down", label: "Y-Axis", value: sensorManager.accelerationY, color: .green)
                        .accessibilityLabel("Y-axis acceleration \(String(format: "%.3f", sensorManager.accelerationY))")
                    SensorReadingCard(icon: "arrow.up.down.and.arrow.left.and.right", label: "Z-Axis", value: sensorManager.accelerationZ, color: .orange)
                        .accessibilityLabel("Z-axis acceleration \(String(format: "%.3f", sensorManager.accelerationZ))")
                }
                .accessibilityElement(children: .contain)
                .accessibilityLabel("Live accelerometer data: X, Y, Z axes")
            }
        }
        .padding(18)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(.ultraThinMaterial)
                .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(.white.opacity(0.1), lineWidth: 1))
                .shadow(color: .black.opacity(0.3), radius: 12, x: 0, y: 4)
        )
        .frame(maxWidth: .infinity)
    }
    
    private func saveFallLocation(waypointStore: WaypointStore, locationManager: LocationManager) {
        guard let loc = locationManager.userLocation else { return }
        let wp = SavedWaypoint(
            latitude: loc.coordinate.latitude,
            longitude: loc.coordinate.longitude,
            timestamp: Date(),
            label: "Fall detected"
        )
        waypointStore.add(wp)
    }
    
    private func sendEmergencySMS(reason: String, locationManager: LocationManager) {
        Task { @MainActor in
            let contacts = EmergencyContactStore.shared.contacts
            guard !contacts.isEmpty else { return }
            
            let locationText: String
            if let loc = locationManager.userLocation {
                locationText = "Location: https://maps.apple.com/?ll=\(loc.coordinate.latitude),\(loc.coordinate.longitude)"
            } else {
                locationText = "Location: Unable to determine"
            }
            
            let message = "🚨 EMERGENCY ALERT 🚨\n\n\(reason).\n\n\(locationText)\n\nSent from OSB Safety App"
            
            if MFMessageComposeViewController.canSendText() {
                let controller = MFMessageComposeViewController()
                controller.messageComposeDelegate = MessageDelegate.shared
                controller.recipients = contacts.map { $0.phoneNumber }
                controller.body = message
                
                // Find topmost view controller
                if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                   let window = windowScene.windows.first,
                   let rootVC = window.rootViewController {
                    var topVC = rootVC
                    while let presented = topVC.presentedViewController {
                        topVC = presented
                    }
                    topVC.present(controller, animated: true)
                }
            } else {
                // Fallback: open Messages app with pre-filled content
                let phoneNumbers = contacts.map { $0.phoneNumber }.joined(separator: ",")
                let encodedMessage = message.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                if let url = URL(string: "sms:\(phoneNumbers)&body=\(encodedMessage)") {
                    UIApplication.shared.open(url)
                }
            }
        }
    }
}

// MARK: - Message Delegate for SMS
// MARK: - Message Delegate for SMS
@MainActor
final class MessageDelegate: NSObject, MFMessageComposeViewControllerDelegate {
    static let shared = MessageDelegate()
    
    // Add 'nonisolated' to satisfy the protocol requirement
    nonisolated func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        
        // Use Task to move back to the MainActor for UI work
        Task { @MainActor in
            controller.dismiss(animated: true)
        }
    }
}
// MARK: - Component Views (StatusCard, SensorReadingCard, etc.) - SAME AS ORIGINAL
struct SensorReadingCard: View {
    let icon: String
    let label: String
    let value: Double
    let color: Color
    @Environment(\.horizontalSizeClass) private var hSizeClass
    
    var body: some View {
        Group {
            if hSizeClass == .regular {
                // iPad Layout: Stack vertically because the cards are arranged side-by-side
                VStack(spacing: 8) {
                    ZStack {
                        Circle()
                            .fill(color.opacity(0.15))
                            .frame(width: 44, height: 44)
                        Image(systemName: icon)
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(color)
                    }
                    
                    Text(label)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.white.opacity(0.9))
                    
                    Text(String(format: "%.3f", value))
                        .font(.system(size: 15, weight: .bold, design: .monospaced))
                        .foregroundColor(.white)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .frame(maxWidth: .infinity)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(.white.opacity(0.08))
                        )
                }
                .padding(12)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(.white.opacity(0.03))
                        .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(.white.opacity(0.05), lineWidth: 1))
                )
            } else {
                // iPhone Layout: Keep it as a clean wide row
                HStack(spacing: 15) {
                    ZStack {
                        Circle()
                            .fill(color.opacity(0.15))
                            .frame(width: 40, height: 40)
                        Image(systemName: icon)
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(color)
                    }
                    Text(label)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.white)
                    
                    Spacer()
                    
                    Text(String(format: "%.3f", value))
                        .font(.system(size: 16, weight: .bold, design: .monospaced))
                        .foregroundColor(.white)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(.white.opacity(0.08))
                        )
                }
                .padding(.vertical, 4)
            }
        }
        .frame(maxWidth: .infinity)
    }
}

struct StatusCard: View {
    let isMonitoring: Bool
    let fallDetected: Bool
    let inactivityDetected: Bool
    @Environment(\.horizontalSizeClass) private var hSizeClass
    
    var body: some View {
        HStack(spacing: 15) {
            ZStack {
                Circle().fill(statusColor.opacity(0.5)).frame(width: hSizeClass == .regular ? 56 : 48, height: hSizeClass == .regular ? 56 : 48)
                Image(systemName: statusIcon).font(.system(size: hSizeClass == .regular ? 28 : 24)).foregroundColor(.white)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(statusTitle)
                    .font(.system(size: hSizeClass == .regular ? 18 : 16, weight: .bold))
                    .foregroundColor(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                Text(statusSubtitle)
                    .font(.system(size: hSizeClass == .regular ? 15 : 13, weight: .regular))
                    .foregroundColor(.white.opacity(0.7))
                    .lineLimit(2)
            }
            Spacer()
        }
        .padding(hSizeClass == .regular ? 20 : 16)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(.ultraThinMaterial)
                .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(.white.opacity(0.08), lineWidth: 1))
                .shadow(color: .black.opacity(0.2), radius: 8, x: 0, y: 4)
        )
    }
    
    private var statusColor: Color {
        if fallDetected { return .red }
        if inactivityDetected { return .yellow }
        if isMonitoring { return .green }
        return .gray
    }
    
    private var statusIcon: String {
        if fallDetected { return "exclamationmark.triangle.fill" }
        if inactivityDetected { return "bell.and.waves.left.and.right.fill" }
        if isMonitoring { return "checkmark.circle.fill" }
        return "pause.circle.fill"
    }
    
    private var statusTitle: String {
        if fallDetected { return "Fall Detected!" }
        if inactivityDetected { return "No Movement Detected" }
        if isMonitoring { return "Active Monitoring" }
        return "Monitoring Stopped"
    }
    
    private var statusSubtitle: String {
        if fallDetected { return "Emergency SOS countdown running" }
        if inactivityDetected { return "Tap 'I'm OK' to confirm you're safe" }
        if isMonitoring { return "Sensors are tracking movement" }
        return "Open the app to start monitoring"
    }
}

struct InfoCard: View {
    @Environment(\.horizontalSizeClass) private var hSizeClass
    
    var body: some View {
        VStack(alignment: .leading, spacing: hSizeClass == .regular ? 14 : 10) {
            HStack {
                Image(systemName: "info.circle.fill")
                    .font(.system(size: hSizeClass == .regular ? 22 : 18))
                    .foregroundColor(.blue)
                    .opacity(0.7)
                Text("How It Works")
                    .font(.system(size: hSizeClass == .regular ? 20 : 16, weight: .bold))
                    .foregroundColor(.white)
            }
            VStack(alignment: .leading, spacing: hSizeClass == .regular ? 10 : 6) {
                InfoRow(icon: "waveform.path", text: "Monitors accelerometer 10x per second")
                InfoRow(icon: "exclamationmark.triangle", text: "Detects sudden falls automatically")
                InfoRow(icon: "sos", text: "Triggers SOS countdown if needed")
                InfoRow(icon: "bell.badge", text: "Alerts on prolonged inactivity")
            }
        }
        .padding(hSizeClass == .regular ? 24 : 16)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(.ultraThinMaterial)
                .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(.white.opacity(0.08), lineWidth: 1))
                .shadow(color: .black.opacity(0.2), radius: 8, x: 0, y: 4)
        )
    }
}

struct InfoRow: View {
    let icon: String
    let text: String
    @Environment(\.horizontalSizeClass) private var hSizeClass
    
    var body: some View {
        HStack(spacing: hSizeClass == .regular ? 14 : 10) {
            Image(systemName: icon)
                .font(.system(size: hSizeClass == .regular ? 16 : 12))
                .foregroundColor(.cyan)
                .frame(width: hSizeClass == .regular ? 24 : 18)
            Text(text)
                .font(.system(size: hSizeClass == .regular ? 16 : 13))
                .foregroundColor(.white.opacity(0.8))
                .lineLimit(nil)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}

struct SOSCountdownView: View {
    let countdown: Int
    var body: some View {
        ZStack {
            Color.black.opacity(0.72).ignoresSafeArea()
            VStack(spacing: 18) {
                ZStack {
                    Circle().fill(Color.red.opacity(0.2)).frame(width: 90, height: 90)
                    Image(systemName: "sos").font(.system(size: 38, weight: .bold)).foregroundColor(.red)
                }.shadow(color: .red.opacity(0.5), radius: 15)
                Text("EMERGENCY SOS").font(.system(size: 22, weight: .bold, design: .rounded)).foregroundColor(.red).tracking(1.5)
                ZStack {
                    Circle().stroke(Color.red.opacity(0.3), lineWidth: 6).frame(width: 110, height: 110)
                    Circle()
                        .trim(from: 0, to: CGFloat(countdown) / 10.0)
                        .stroke(Color.red, style: StrokeStyle(lineWidth: 6, lineCap: .round))
                        .frame(width: 110, height: 110)
                        .rotationEffect(.degrees(-90))
                        .animation(.linear(duration: 1.0), value: countdown)
                    Text("\(countdown)").font(.system(size: 52, weight: .bold, design: .rounded)).foregroundColor(.white)
                }
                VStack(spacing: 6) {
                    Text("Fall detected!").font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
                    Text("Emergency services will be contacted").font(.system(size: 13)).foregroundColor(.white.opacity(0.8)).multilineTextAlignment(.center)
                }
                Text("Shake device to cancel").font(.system(size: 12)).foregroundColor(.white.opacity(0.6)).italic()
            }
            .padding(24)
            .background(
                RoundedRectangle(cornerRadius: 24)
                    .fill(.ultraThinMaterial)
                    .overlay(RoundedRectangle(cornerRadius: 24).strokeBorder(Color.red.opacity(0.25), lineWidth: 1))
                    .shadow(color: .red.opacity(0.3), radius: 20)
            )
            .padding(.horizontal, 20)
        }
    }
}

struct InactivityAlarmView: View {
    let seconds: Int
    let thresholdSeconds: Int
    let pulse: Bool
    let onImOk: () -> Void
    let onTriggerSOS: () -> Void
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.72).ignoresSafeArea()
            VStack(spacing: 14) {
                ZStack {
                    Circle().fill(Color.yellow.opacity(0.18)).frame(width: 90, height: 90)
                        .scaleEffect(pulse ? 1.06 : 1.0)
                        .animation(.easeInOut(duration: 0.7).repeatForever(autoreverses: true), value: pulse)
                    Image(systemName: "bell.and.waves.left.and.right.fill").font(.system(size: 34, weight: .bold)).foregroundColor(.yellow)
                }.shadow(color: .yellow.opacity(0.35), radius: 18)
                Text("ARE YOU OK?").font(.system(size: 20, weight: .bold, design: .rounded)).foregroundColor(.white).tracking(1.2)
                Text("No significant movement for \(formatSeconds(seconds))").font(.system(size: 14, weight: .medium)).foregroundColor(.white.opacity(0.8))
                Text("Tap 'I'm OK' to silence the alarm.\nIf you need help, trigger SOS.").font(.system(size: 13)).foregroundColor(.white.opacity(0.72)).multilineTextAlignment(.center)
                VStack(spacing: 8) {
                    Button(action: onImOk) {
                        HStack(spacing: 8) {
                            Image(systemName: "checkmark.seal.fill").font(.system(size: 14, weight: .semibold))
                            Text("I'm OK").font(.system(size: 15, weight: .bold, design: .rounded))
                        }
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(RoundedRectangle(cornerRadius: 14).fill(Color.yellow))
                    }
                    Button(action: onTriggerSOS) {
                        HStack(spacing: 8) {
                            Image(systemName: "sos").font(.system(size: 14, weight: .semibold))
                            Text("Trigger SOS").font(.system(size: 15, weight: .bold, design: .rounded))
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(RoundedRectangle(cornerRadius: 14).fill(Color.red.opacity(0.85)))
                    }
                }.padding(.top, 4)
                Text("Auto-alert after \(formatSeconds(thresholdSeconds))").font(.system(size: 11, weight: .semibold, design: .monospaced)).foregroundColor(.white.opacity(0.6))
            }
            .padding(20)
            .background(
                RoundedRectangle(cornerRadius: 22)
                    .fill(.ultraThinMaterial)
                    .overlay(RoundedRectangle(cornerRadius: 22).strokeBorder(Color.yellow.opacity(0.25), lineWidth: 1))
                    .shadow(color: .black.opacity(0.35), radius: 24, x: 0, y: 10)
            )
            .padding(.horizontal, 20)
        }
    }
    
    private func formatSeconds(_ total: Int) -> String {
        let m = total / 60
        let s = total % 60
        if m <= 0 { return "\(s)s" }
        return "\(m)m \(s)s"
    }
}

// MARK: - Core ML model bundle lookup (Swift Playgrounds + Xcode)
private enum OutdoorClassifierModel {
    private static let resourceName = "OutdoorClassifier"
    
    static func locateCompiledModelURL() -> URL? {
        let bundles: [Bundle] = [Bundle.main, Bundle.module]
        let candidates: [(ext: String, subdir: String?)] = [
            ("mlmodelc", nil),
            ("mlmodelc", "Resources"),
            ("mlmodel", nil),
            ("mlmodel", "Resources")
        ]
        
        for bundle in bundles {
            for candidate in candidates {
                if let url = bundle.url(
                    forResource: resourceName,
                    withExtension: candidate.ext,
                    subdirectory: candidate.subdir
                ) {
                    return url
                }
            }
        }
        return nil
    }
}

// MARK: - Camera picker for taking injury photos
private struct CameraPicker: UIViewControllerRepresentable {
    @Environment(\.dismiss) private var dismiss
    let onImageCaptured: (Data) -> Void
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = .camera
        picker.delegate = context.coordinator
        picker.cameraCaptureMode = .photo
        picker.allowsEditing = false
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    final class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: CameraPicker
        
        init(parent: CameraPicker) {
            self.parent = parent
        }
        
        func imagePickerController(
            _ picker: UIImagePickerController,
            didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]
        ) {
            if let image = info[.originalImage] as? UIImage,
               let data = image.jpegData(compressionQuality: 0.8) {
                parent.onImageCaptured(data)
            }
            parent.dismiss()
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.dismiss()
        }
    }
}

// MARK: - Sample images for First Aid testing
struct SampleImageInfo {
    let name: String
    let preview: UIImage
    let imageData: Data
}

// MARK: - AI First Aid Screen (iPad-optimized with horizontal layout)
struct AIFirstAidScreen: View {
    private static let sampleImageInfos: [SampleImageInfo] = {
        // 1. List the EXACT names of the images in your sidebar (no .jpg needed)
        let imageNames = ["Cut", "Bruise", "Burn", "Abrasion"]
        
        return imageNames.map { name in
            // 2. Try to load your custom image, fallback to a system icon if missing
            let img = UIImage(named: name) ?? UIImage(systemName: "photo.fill")!
            
            // 3. Convert to Data so the AI can read it later
            let data = img.jpegData(compressionQuality: 0.8) ?? Data()
            
            return SampleImageInfo(name: name, preview: img, imageData: data)
        }
    }()
    private static func makeSampleImage(label: String, color: UIColor, size: CGFloat = 200) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: size, height: size))
        return renderer.image { ctx in
            color.setFill()
            ctx.fill(CGRect(origin: .zero, size: CGSize(width: size, height: size)))
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .center
            let attrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.boldSystemFont(ofSize: min(size * 0.15, 28)),
                .foregroundColor: UIColor.white,
                .paragraphStyle: paragraphStyle
            ]
            let rect = CGRect(x: 0, y: (size - (size * 0.2)) / 2, width: size, height: size * 0.25)
            label.draw(in: rect, withAttributes: attrs)
        }
    }
    
    private let firstAidAdvice: [String: String] = [
        "Cut": "1. Wash cut with soap/water\n2. Apply petroleum jelly\n3. Cover with sterile bandage\n https://medlineplus.gov/ency/article/000043.htm",
        "Burn": "1. Cool water 10 mins\n2. Loose sterile gauze\n3. NO ice!\n https://www.redcross.org/take-a-class/resources/learn-first-aid/burns",
        "Abrasion": "1. Clean with soap/water\n2. Antibiotic ointment\n3. Clean bandage\n https://medlineplus.gov/ency/article/000043.htm",
        "Bite": "1. Wash thoroughly\n2. Cold pack\n3. Watch for infection\n https://www.nhs.uk/conditions/insect-bites-and-stings/",
        "Bruise": "1. Ice 10-20 mins\n2. Compress\n3. Elevate\n https://www.mhsystem.org/health-library/art-20056663/",
        "Normal": "No injury detected. Monitor."
    ]
    
    @State private var selectedItems: [PhotosPickerItem] = []
    @State private var imageData: Data?
    @State private var treatmentOutput: String = ""
    @State private var isAnalyzing: Bool = false
    @State private var lastError: String?
    @State private var showCamera = false
    @Environment(\.horizontalSizeClass) private var hSizeClass
    
    private var cameraAvailable: Bool {
        UIImagePickerController.isSourceTypeAvailable(.camera)
    }
    
    private var resultDisplayText: String {
        if isAnalyzing { return "Analyzing image…" }
        if let err = lastError { return err }
        if treatmentOutput.isEmpty { return "Take or select a photo → tap Analyze → get first aid steps" }
        return treatmentOutput
    }
    
    private var resultDisplayColor: Color {
        if lastError != nil { return .red.opacity(0.95) }
        if treatmentOutput.isEmpty && !isAnalyzing { return .white.opacity(0.5) }
        return .white
    }
    
    var body: some View {
        Group {
            if hSizeClass == .regular {
                iPadLayout
            } else {
                iPhoneLayout
            }
        }
        .background {
            Image("mountainBackground")
                .resizable()
                .scaledToFill()
                .overlay(Color.black.opacity(0.35))
                .ignoresSafeArea()
        }
        .onChange(of: selectedItems) { newItems in
            Task {
                if let item = newItems.first, let data = try? await item.loadTransferable(type: Data.self) {
                    await MainActor.run { imageData = data }
                }
            }
        }
        .fullScreenCover(isPresented: $showCamera) {
            CameraPicker { data in
                selectedItems = []
                imageData = data
                lastError = nil
                treatmentOutput = ""
            }
            .ignoresSafeArea()
        }
    }
    
    private var iPhoneLayout: some View {
        ScrollView {
            VStack(spacing: 20) {
                headerSection
                imagePreviewSection(maxHeight: 250)
                buttonsSection
                resultsSection
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(
                        RoundedRectangle(cornerRadius: 16)
                            .fill(.ultraThinMaterial)
                            .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(.white.opacity(0.1), lineWidth: 1))
                    )
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 32)
            .frame(maxWidth: .infinity)
        }
    }
    
    private var iPadLayout: some View {
        ScrollView {
            HStack(alignment: .top, spacing: 32) {
                VStack(spacing: 24) {
                    headerSection
                    imagePreviewSection(maxHeight: 350)
                    buttonsSection
                }
                .frame(maxWidth: 420)
                
                resultsSection
                    .padding(20)
                    .frame(maxWidth: .infinity, minHeight: 280, alignment: .topLeading)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(.ultraThinMaterial)
                            .overlay(RoundedRectangle(cornerRadius: 20).strokeBorder(.white.opacity(0.1), lineWidth: 1))
                    )
            }
            .padding(.horizontal, 32)
            .padding(.vertical, 24)
            .frame(maxWidth: .infinity)
        }
    }
    
    @ViewBuilder
    private func imagePreviewSection(maxHeight: CGFloat) -> some View {
        if let data = imageData, let uiImage = UIImage(data: data) {
            Image(uiImage: uiImage)
                .resizable()
                .scaledToFit()
                .frame(maxHeight: maxHeight)
                .frame(maxWidth: .infinity)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(color: .black.opacity(0.25), radius: 8, x: 0, y: 4)
                .accessibilityLabel("Selected image for analysis")
        } else {
            RoundedRectangle(cornerRadius: 16)
                .fill(Color.white.opacity(0.08))
                .frame(height: maxHeight * 0.75)
                .frame(maxWidth: .infinity)
                .overlay {
                    VStack(spacing: 8) {
                        Image(systemName: "photo.on.rectangle.angled")
                            .font(.system(size: 36))
                            .foregroundColor(.white.opacity(0.4))
                        Text("No image selected")
                            .font(.subheadline.weight(.medium))
                            .foregroundColor(.white.opacity(0.5))
                    }
                }
                .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(.white.opacity(0.12), lineWidth: 1))
        }
    }
    
    private var headerSection: some View {
        VStack(spacing: 8) {
            Image(systemName: "cross.case.fill")
                .font(.system(size: hSizeClass == .regular ? 40 : 30))
                .foregroundStyle(.white, .green)
            Text("AI First Aid")
                .font(.system(size: hSizeClass == .regular ? 36 : 28, weight: .bold))
                .foregroundColor(.white)
            Text("Analyze your injury")
                .font(.system(size: hSizeClass == .regular ? 16 : 14, weight: .medium))
                .foregroundColor(.white.opacity(0.7))
        }
        .padding(.top, hSizeClass == .regular ? 12 : 8)
        .frame(maxWidth: .infinity)
    }
    
    private var buttonsSection: some View {
        VStack(spacing: 16) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Try sample images")
                    .font(.system(size: hSizeClass == .regular ? 17 : 15, weight: .semibold))
                    .foregroundColor(.white.opacity(0.9))
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(Self.sampleImageInfos, id: \.name) { info in
                            Button {
                                selectedItems = []
                                imageData = info.imageData
                            } label: {
                                VStack(spacing: 4) {
                                    Image(uiImage: info.preview)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 72, height: 72)
                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                    Text(info.name)
                                        .font(.caption2)
                                        .foregroundColor(.white)
                                        .lineLimit(1)
                                }
                                .frame(width: 80)
                                .padding(6)
                                .background(
                                    RoundedRectangle(cornerRadius: 12)
                                        .fill(imageData == info.imageData ? Color.green.opacity(0.4) : Color.white.opacity(0.1))
                                )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
            
            if cameraAvailable {
                Button {
                    showCamera = true
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "camera.fill")
                            .font(.system(size: hSizeClass == .regular ? 18 : 16, weight: .semibold))
                        Text("Take Photo")
                            .font(.system(size: hSizeClass == .regular ? 18 : 16, weight: .semibold))
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, hSizeClass == .regular ? 16 : 14)
                    .background(Color.orange, in: RoundedRectangle(cornerRadius: 16))
                }
                .accessibilityLabel("Take photo with camera")
                .accessibilityHint("Opens the camera to photograph an injury")
            }
            
            PhotosPicker(selection: $selectedItems, maxSelectionCount: 1, matching: .images) {
                HStack(spacing: 8) {
                    Image(systemName: "photo.on.rectangle")
                        .font(.system(size: hSizeClass == .regular ? 18 : 16, weight: .semibold))
                    Text("Choose from Library")
                        .font(.system(size: hSizeClass == .regular ? 18 : 16, weight: .semibold))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, hSizeClass == .regular ? 16 : 14)
                .background(imageData == nil ? Color.blue : Color.green, in: RoundedRectangle(cornerRadius: 16))
            }
            .accessibilityLabel("Select image from photo library")
            .accessibilityHint("Opens photo picker to choose an injury photo")
            
            Button {
                analyzeInjury()
            } label: {
                HStack(spacing: 8) {
                    if isAnalyzing {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .scaleEffect(0.9)
                    }
                    Text(isAnalyzing ? "Analyzing…" : "Analyze Image")
                        .font(.system(size: hSizeClass == .regular ? 18 : 16, weight: .bold))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, hSizeClass == .regular ? 16 : 14)
                .background(imageData == nil ? Color.gray : (isAnalyzing ? Color.blue : Color.green), in: RoundedRectangle(cornerRadius: 16))
            }
            .disabled(imageData == nil || isAnalyzing)
            .accessibilityLabel("Classify image")
            .accessibilityHint("Runs the AI model to classify the injury and show first aid steps")
        }
        .padding(16)
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(.ultraThinMaterial)
                .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(.white.opacity(0.1), lineWidth: 1))
        )
    }
    
    private var resultsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Label("Analysis & Treatment", systemImage: "doc.text.magnifyingglass")
                .font(hSizeClass == .regular ? .title2.bold() : .headline.bold())
                .foregroundColor(.white)
            
            Divider().background(Color.white.opacity(0.3))
            
            Text(LocalizedStringKey(resultDisplayText))
                            .font(.system(size: hSizeClass == .regular ? 20 : 16, design: .rounded))
                            .foregroundColor(resultDisplayColor)
                            .tint(.blue) // Sets the clickable link color
                            .lineSpacing(6)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .fixedSize(horizontal: false, vertical: true)
                        
            Text("Disclaimer: AI advice is for informational purposes only. Consult a healthcare professional for medical emergencies.")
                            .font(.caption2)
                            .foregroundColor(.white.opacity(0.6))
                            .padding(.top, 8)
        }
    }
    
    private func analyzeInjury() {
        guard let data = imageData else { return }
        isAnalyzing = true
        lastError = nil
        treatmentOutput = ""
        
        Task {
            let result = await analyzeWithRealAI(imageData: data)
            await MainActor.run {
                let isError = result.hasPrefix("❌") || result.contains("Model Error") || result.contains("Model not found")
                if isError {
                    lastError = result
                    treatmentOutput = ""
                } else {
                    treatmentOutput = result
                    lastError = nil
                }
                isAnalyzing = false
            }
        }
    }
    
    // Load Core ML model by URL (no generated Swift class required – avoids "No predominant language" codegen error)
    private func analyzeWithRealAI(imageData: Data) async -> String {
        guard let ciImage = CIImage(data: imageData) else {
            return "❌ Error: Cannot process image"
        }
        
        guard let modelURL = OutdoorClassifierModel.locateCompiledModelURL() else {
            return "❌ Model not found. Add OutdoorClassifier.mlmodelc to Resources."
        }
        
        do {
            let model = try MLModel(contentsOf: modelURL)
            return try await runVisionRequest(model: model, ciImage: ciImage)
        } catch {
            return "❌ Model Error: \(error.localizedDescription)"
        }
    }
    
    private func runVisionRequest(model: MLModel, ciImage: CIImage) async throws -> String {
        try await withCheckedThrowingContinuation { continuation in
            let visionModel = try! VNCoreMLModel(for: model)
            let request = VNCoreMLRequest(model: visionModel) { request, error in
                if let error = error {
                    continuation.resume(throwing: error)
                    return
                }
                
                guard let results = request.results as? [VNClassificationObservation],
                      let topResult = results.first else {
                    continuation.resume(returning: "🤖 AI found no injury type")
                    return
                }
                
                let label = topResult.identifier
                let confidence = Int(topResult.confidence * 100)
                let advice = firstAidAdvice[label] ?? firstAidAdvice["Normal"]!
                
                continuation.resume(returning: "✅ \(label) (\(confidence)% confidence)\n\n\(advice)")
            }
            
            let handler = VNImageRequestHandler(ciImage: ciImage)
            try? handler.perform([request])
        }
    }
}

// MARK: - Emergency Contacts

struct EmergencyContact: Identifiable, Codable, Equatable {
    let id: UUID
    var name: String
    var phoneNumber: String
    
    init(id: UUID = UUID(), name: String, phoneNumber: String) {
        self.id = id
        self.name = name
        self.phoneNumber = phoneNumber
    }
}

@MainActor
final class EmergencyContactStore: ObservableObject {
    static let shared = EmergencyContactStore()
    private let key = "OSB.emergencyContacts"
    @Published var contacts: [EmergencyContact] = []
    
    private init() { load() }
    
    func add(_ contact: EmergencyContact) {
        contacts.append(contact)
        save()
    }
    
    func update(_ contact: EmergencyContact) {
        if let index = contacts.firstIndex(where: { $0.id == contact.id }) {
            contacts[index] = contact
            save()
        }
    }
    
    func remove(_ contact: EmergencyContact) {
        contacts.removeAll { $0.id == contact.id }
        save()
    }
    
    func removeAll() {
        contacts.removeAll()
        save()
    }
    
    private func load() {
        guard let data = UserDefaults.standard.data(forKey: key),
              let decoded = try? JSONDecoder().decode([EmergencyContact].self, from: data) else { return }
        contacts = decoded
    }
    
    private func save() {
        guard let data = try? JSONEncoder().encode(contacts) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }
}

struct EmergencyContactsScreen: View {
    @ObservedObject private var contactStore = EmergencyContactStore.shared
    @EnvironmentObject private var locationManager: LocationManager
    @Environment(\.horizontalSizeClass) private var hSizeClass
    @State private var showingAddContact = false
    @State private var editingContact: EmergencyContact?
    
    var body: some View {
        ScrollView {
            VStack(spacing: hSizeClass == .regular ? 24 : 16) {
                headerSection
                addContactButton
                contactsContent
            }
            .padding(.horizontal, hSizeClass == .regular ? 48 : 16)
            .padding(.bottom, 40)
            .frame(maxWidth: hSizeClass == .regular ? 720 : .infinity)
            .frame(maxWidth: .infinity)
        }
        .background {
            Image("mountainBackground")
                .resizable()
                .scaledToFill()
                .overlay(Color.black.opacity(0.35))
                .ignoresSafeArea()
        }
        .sheet(isPresented: $showingAddContact) {
            AddEditContactView(contact: nil, onSave: { contact in
                contactStore.add(contact)
            })
        }
        .sheet(item: $editingContact) { contact in
            AddEditContactView(contact: contact, onSave: { updated in
                contactStore.update(updated)
                editingContact = nil
            })
        }
        .onAppear {
            locationManager.requestPermission()
            locationManager.startUpdating()
        }
    }
    
    private var addContactButton: some View {
        Button {
            showingAddContact = true
        } label: {
            HStack(spacing: 10) {
                Image(systemName: "plus.circle.fill")
                    .font(.system(size: hSizeClass == .regular ? 22 : 20))
                Text("Add Emergency Contact")
                    .font(.system(size: hSizeClass == .regular ? 18 : 16, weight: .semibold))
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, hSizeClass == .regular ? 18 : 14)
            .background(Color.blue, in: RoundedRectangle(cornerRadius: 14))
        }
        .accessibilityLabel("Add emergency contact")
    }
    
    @ViewBuilder
    private var contactsContent: some View {
        if contactStore.contacts.isEmpty {
            VStack(spacing: 12) {
                Image(systemName: "person.crop.circle.badge.plus")
                    .font(.system(size: hSizeClass == .regular ? 56 : 48))
                    .foregroundColor(.white.opacity(0.5))
                Text("No emergency contacts")
                    .font(hSizeClass == .regular ? .title3.weight(.semibold) : .headline)
                    .foregroundColor(.white.opacity(0.7))
                Text("Add contacts to receive automatic alerts when a fall or inactivity is detected")
                    .font(hSizeClass == .regular ? .body : .subheadline)
                    .foregroundColor(.white.opacity(0.6))
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, hSizeClass == .regular ? 40 : 32)
            .padding(.horizontal, 8)
            .padding(20)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(.ultraThinMaterial)
                    .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(.white.opacity(0.1), lineWidth: 1))
            )
        } else {
            VStack(spacing: 12) {
                ForEach(contactStore.contacts) { contact in
                    ContactRow(
                        contact: contact,
                        onEdit: { editingContact = $0 },
                        onDelete: { contactStore.remove($0) }
                    )
                }
            }
        }
    }
    
    private var headerSection: some View {
        VStack(spacing: 12) {
            Image(systemName: "person.2.fill")
                .font(.system(size: hSizeClass == .regular ? 44 : 36))
                .foregroundStyle(.white, .blue)
            Text("Emergency Contacts")
                .font(.system(size: hSizeClass == .regular ? 32 : 26, weight: .bold))
                .foregroundColor(.white)
            Text("Contacts will receive SMS alerts with your location")
                .font(.system(size: hSizeClass == .regular ? 16 : 14))
                .foregroundColor(.white.opacity(0.7))
                .multilineTextAlignment(.center)
        }
        .padding(.top, hSizeClass == .regular ? 24 : 16)
        .padding(.bottom, 8)
        .frame(maxWidth: .infinity)
    }
}

struct ContactRow: View {
    let contact: EmergencyContact
    let onEdit: (EmergencyContact) -> Void
    let onDelete: (EmergencyContact) -> Void
    @Environment(\.horizontalSizeClass) private var hSizeClass
    
    var body: some View {
        HStack(spacing: hSizeClass == .regular ? 16 : 12) {
            ZStack {
                Circle()
                    .fill(Color.blue.opacity(0.3))
                    .frame(width: hSizeClass == .regular ? 56 : 48, height: hSizeClass == .regular ? 56 : 48)
                Image(systemName: "person.fill")
                    .font(.system(size: hSizeClass == .regular ? 24 : 20))
                    .foregroundColor(.blue)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(contact.name)
                    .font(.system(size: hSizeClass == .regular ? 18 : 16, weight: .semibold))
                    .foregroundColor(.white)
                    .lineLimit(2)
                Text(contact.phoneNumber)
                    .font(.system(size: hSizeClass == .regular ? 16 : 14))
                    .foregroundColor(.white.opacity(0.7))
                    .lineLimit(1)
                    .minimumScaleFactor(0.85)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            
            HStack(spacing: hSizeClass == .regular ? 16 : 12) {
                Button {
                    onEdit(contact)
                } label: {
                    Image(systemName: "pencil.circle.fill")
                        .font(.system(size: hSizeClass == .regular ? 32 : 28))
                        .foregroundColor(.cyan)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Edit contact")
                
                Button {
                    onDelete(contact)
                } label: {
                    Image(systemName: "trash.circle.fill")
                        .font(.system(size: hSizeClass == .regular ? 32 : 28))
                        .foregroundColor(.red.opacity(0.9))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Delete contact")
            }
            .layoutPriority(1)
        }
        .padding(hSizeClass == .regular ? 18 : 14)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(.ultraThinMaterial)
                .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(.white.opacity(0.1), lineWidth: 1))
        )
    }
}

struct AddEditContactView: View {
    let contact: EmergencyContact?
    let onSave: (EmergencyContact) -> Void
    @Environment(\.dismiss) private var dismiss
    @Environment(\.horizontalSizeClass) private var hSizeClass
    @State private var name: String = ""
    @State private var phoneNumber: String = ""
    @State private var showAlert = false
    
    var isPhoneValid: Bool {
        let clean = phoneNumber.replacingOccurrences(of: " ", with: "")
        return clean.hasPrefix("+") && clean.count >= 11
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    colors: [Color(red: 0.1, green: 0.15, blue: 0.25), Color(red: 0.05, green: 0.1, blue: 0.2)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 24) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Name")
                                .font(.headline)
                                .foregroundColor(.white)
                            TextField("Enter name", text: $name)
                                .textFieldStyle(.roundedBorder)
                                .font(.system(size: hSizeClass == .regular ? 18 : 16))
                        }
                        
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Phone Number")
                                .font(.headline)
                                .foregroundColor(.white)
                            TextField("Enter phone number (e.g. +1...)", text: $phoneNumber)
                                .keyboardType(.phonePad)
                                .textFieldStyle(.roundedBorder)
                                .font(.system(size: hSizeClass == .regular ? 18 : 16))
                            Text("Include country code starting with '+'")
                                .font(.caption)
                                .foregroundColor(.white.opacity(0.7))
                        }
                        
                        Button {
                            if isPhoneValid && !name.isEmpty {
                                let newContact = EmergencyContact(
                                    id: contact?.id ?? UUID(),
                                    name: name,
                                    phoneNumber: phoneNumber
                                )
                                onSave(newContact)
                                dismiss()
                            } else {
                                showAlert = true
                            }
                        } label: {
                            Text(contact == nil ? "Add Contact" : "Save Changes")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, hSizeClass == .regular ? 18 : 14)
                                .background(name.isEmpty || phoneNumber.isEmpty ? Color.blue : Color.green, in: RoundedRectangle(cornerRadius: 14))
                        }
                        .disabled(name.isEmpty || phoneNumber.isEmpty)
                    }
                    .padding(hSizeClass == .regular ? 32 : 24)
                    .frame(maxWidth: hSizeClass == .regular ? 520 : .infinity)
                    .frame(maxWidth: .infinity)
                }
            }
            .navigationTitle(contact == nil ? "Add Contact" : "Edit Contact")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Cancel") { dismiss() }
                        .foregroundColor(.white)
                }
            }
            .alert("Check Phone Number", isPresented: $showAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("Please include your country code starting with '+' (e.g., +1 555...). This ensures your SOS messages are sent correctly.")
            }
        }
        .presentationDetents(hSizeClass == .regular ? [.medium, .large] : [.large])
        .presentationDragIndicator(.visible)
        .onAppear {
            if let contact = contact {
                name = contact.name
                phoneNumber = contact.phoneNumber
            }
        }
    }
}

// MARK: - Map & Wayfinder (saved locations when lost + AR wayfinding)

struct SavedWaypoint: Identifiable, Codable, Equatable {
    let id: UUID
    let latitude: Double
    let longitude: Double
    let timestamp: Date
    var label: String
    
    var coordinate: CLLocationCoordinate2D { CLLocationCoordinate2D(latitude: latitude, longitude: longitude) }
    var clLocation: CLLocation { CLLocation(latitude: latitude, longitude: longitude) }
    
    init(id: UUID = UUID(), latitude: Double, longitude: Double, timestamp: Date = Date(), label: String = "") {
        self.id = id
        self.latitude = latitude
        self.longitude = longitude
        self.timestamp = timestamp
        self.label = label.isEmpty ? "Saved \(timestamp.formatted(date: .abbreviated, time: .shortened))" : label
    }
}

final class WaypointStore: ObservableObject {
    private let key = "OSB.savedWaypoints"
    @Published var waypoints: [SavedWaypoint] = []
    
    init() { load() }
    
    func add(_ waypoint: SavedWaypoint) {
        waypoints.append(waypoint)
        save()
    }
    
    func remove(_ waypoint: SavedWaypoint) {
        waypoints.removeAll { $0.id == waypoint.id }
        save()
    }
    
    func removeAll() {
        waypoints.removeAll()
        save()
    }
    
    private func load() {
        guard let data = UserDefaults.standard.data(forKey: key),
              let decoded = try? JSONDecoder().decode([SavedWaypoint].self, from: data) else { return }
        waypoints = decoded
    }
    
    private func save() {
        guard let data = try? JSONEncoder().encode(waypoints) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }
}

import CoreLocation
import Combine

@MainActor
final class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var authorizationStatus: CLAuthorizationStatus = .notDetermined
    @Published var userLocation: CLLocation?
    @Published var trueHeading: CLLocationDirection = 0
    @Published var locationError: String?
    
    private let manager = CLLocationManager()
    
    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.distanceFilter = 5
        manager.headingFilter = 3
        authorizationStatus = manager.authorizationStatus
        
        // Auto-request authorization and begin updates immediately on launch
        requestPermission()
    }
    
    func requestPermission() {
        if manager.authorizationStatus == .notDetermined {
            manager.requestWhenInUseAuthorization()
        } else if manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways {
            startUpdating()
        }
    }
    
    func startUpdating() {
        manager.startUpdatingLocation()
        if CLLocationManager.headingAvailable() {
            manager.startUpdatingHeading()
        }
    }
    
    func stopUpdating() {
        manager.stopUpdatingLocation()
        manager.stopUpdatingHeading()
    }
    
    func bearing(to waypoint: SavedWaypoint) -> CLLocationDirection? {
        guard let user = userLocation else { return nil }
        let userCoord = user.coordinate
        let wpCoord = waypoint.coordinate
        let dLon = (wpCoord.longitude - userCoord.longitude) * .pi / 180
        let lat1 = userCoord.latitude * .pi / 180
        let lat2 = wpCoord.latitude * .pi / 180
        let y = sin(dLon) * cos(lat2)
        let x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        var bearing = atan2(y, x) * 180 / .pi
        if bearing < 0 { bearing += 360 }
        return bearing
    }
    
    func distance(to waypoint: SavedWaypoint) -> CLLocationDistance? {
        return userLocation?.distance(from: waypoint.clLocation)
    }
    
    // MARK: - CLLocationManagerDelegate
    nonisolated func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        Task { @MainActor in
            self.authorizationStatus = manager.authorizationStatus
            if manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways {
                self.startUpdating()
            }
        }
    }
    
    nonisolated func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        Task { @MainActor in
            self.userLocation = location
            self.locationError = nil
        }
    }
    
    nonisolated func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        if newHeading.trueHeading >= 0 {
            Task { @MainActor in
                self.trueHeading = newHeading.trueHeading
            }
        }
    }
    
    nonisolated func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        Task { @MainActor in
            self.locationError = error.localizedDescription
            print("Location Manager Error: \(error.localizedDescription)")
        }
    }
}


struct MapWayfinderScreen: View {
    @EnvironmentObject private var waypointStore: WaypointStore
    @EnvironmentObject private var locationManager: LocationManager
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
        span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)
    )
    @State private var selectedWaypoint: SavedWaypoint?
    @State private var showARWayfinding = false
    @State private var showSaveConfirmation = false
    @State private var hasCenteredOnUser = false // [Q] Add this new state variable
    @Environment(\.horizontalSizeClass) private var hSizeClass
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.05, green: 0.2, blue: 0.35), Color(red: 0.08, green: 0.12, blue: 0.2)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            Group {
                if hSizeClass == .regular {
                    // iPad: horizontal layout - map left, controls right
                    HStack(spacing: 0) {
                        mapSection
                            .frame(maxWidth: .infinity)
                        bottomPanel
                            .frame(width: 400)
                    }
                } else {
                    // iPhone: vertical layout
                    VStack(spacing: 0) {
                        mapSection
                        bottomPanel
                    }
                }
            }
        }
        .sheet(isPresented: $showARWayfinding) {
            if let wp = selectedWaypoint {
                ARWayfindingSheet(waypoint: wp, locationManager: locationManager, onDismiss: { showARWayfinding = false })
            }
        }
        .onAppear {
            locationManager.requestPermission()
            locationManager.startUpdating()
            if let loc = locationManager.userLocation {
                region.center = loc.coordinate
                region.span = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
            }
        }
        .onChange(of: locationManager.userLocation) { newLocation in
            guard let loc = newLocation, !hasCenteredOnUser else { return }
            region.center = loc.coordinate
            hasCenteredOnUser = true // [Q] Stop auto-centering so the user can pan the map freely
        }
        .alert("Location saved", isPresented: $showSaveConfirmation) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("This spot is saved. Use \"Navigate in AR\" from the list to find your way back.")
        }
    }
    
    private var mapSection: some View {
        ZStack {
            Map(coordinateRegion: $region, showsUserLocation: true, annotationItems: waypointStore.waypoints) { wp in
                MapAnnotation(coordinate: wp.coordinate) {
                    Button {
                        selectedWaypoint = wp
                    } label: {
                        VStack(spacing: 2) {
                            Image(systemName: "mappin.circle.fill")
                                .font(.title2)
                                .foregroundColor(.red)
                            Text(wp.label)
                                .font(.caption2)
                                .lineLimit(1)
                                .foregroundColor(.white)
                        }
                    }
                }
            }

            Image(systemName: "plus")
                .font(.title)
                .foregroundColor(.blue)
                .shadow(radius: 2)
                .allowsHitTesting(false) // Allows touch events to pass to the map beneath
        }
    }
private var bottomPanel: some View {
        VStack(spacing: hSizeClass == .regular ? 20 : 12) {
            
            // [Q] NEW BUTTON: Set Destination at Crosshair
            Button {
                setDestinationAtCenter()
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "scope")
                        .font(.system(size: hSizeClass == .regular ? 20 : 18))
                    Text("Set Destination Here")
                        .font(.system(size: hSizeClass == .regular ? 18 : 16, weight: .semibold))
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, hSizeClass == .regular ? 18 : 14)
                .background(Color.green, in: RoundedRectangle(cornerRadius: 14))
            }
            .accessibilityLabel("Set your designated destination here")

            // EXISTING BUTTON: Save Current Location
            Button {
                saveCurrentLocation()
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "location.circle.fill")
                        .font(.system(size: hSizeClass == .regular ? 20 : 18))
                    Text("I'm lost – save my location")
                        .font(.system(size: hSizeClass == .regular ? 18 : 16, weight: .semibold))
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, hSizeClass == .regular ? 18 : 14)
                .background(Color.orange, in: RoundedRectangle(cornerRadius: 14))
            }
            .accessibilityLabel("Save current location when lost")
            
            if !waypointStore.waypoints.isEmpty {
                if hSizeClass == .regular {
                    // iPad: vertical scroll for waypoints
                    ScrollView {
                        VStack(spacing: 12) {
                            ForEach(waypointStore.waypoints) { wp in
                                WaypointChip(
                                    waypoint: wp,
                                    distance: locationManager.distance(to: wp),
                                    isSelected: selectedWaypoint?.id == wp.id,
                                    onTap: { selectedWaypoint = wp },
                                    onAR: {
                                        selectedWaypoint = wp
                                        showARWayfinding = true
                                    },
                                    onDelete: { waypointStore.remove(wp) }
                                )
                            }
                        }
                        .padding(.horizontal, 4)
                    }
                } else {
                    // iPhone: horizontal scroll
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(waypointStore.waypoints) { wp in
                                WaypointChip(
                                    waypoint: wp,
                                    distance: locationManager.distance(to: wp),
                                    isSelected: selectedWaypoint?.id == wp.id,
                                    onTap: { selectedWaypoint = wp },
                                    onAR: {
                                        selectedWaypoint = wp
                                        showARWayfinding = true
                                    },
                                    onDelete: { waypointStore.remove(wp) }
                                )
                            }
                        }
                        .padding(.horizontal, 4)
                    }
                    .frame(maxHeight: 88)
                }
            }
        }
        .padding(hSizeClass == .regular ? 24 : 16)
        .background(.ultraThinMaterial)
    }
    
    private func saveCurrentLocation() {
        guard let loc = locationManager.userLocation else { return }
        let wp = SavedWaypoint(
            latitude: loc.coordinate.latitude,
            longitude: loc.coordinate.longitude,
            timestamp: Date()
        )
        waypointStore.add(wp)
        selectedWaypoint = wp
        showSaveConfirmation = true
    }

    // [Q] new function
    private func setDestinationAtCenter() {
        let destination = SavedWaypoint(
            latitude: region.center.latitude,
            longitude: region.center.longitude,
            timestamp: Date(),
            label: "Designated Target"
        )
        waypointStore.add(destination)
        selectedWaypoint = destination
        showARWayfinding = true // Immediately opens the AR View
    }
}

struct WaypointChip: View {
    let waypoint: SavedWaypoint
    let distance: CLLocationDistance?
    let isSelected: Bool
    let onTap: () -> Void
    let onAR: () -> Void
    let onDelete: () -> Void
    @Environment(\.horizontalSizeClass) private var hSizeClass

    var body: some View {
        HStack(spacing: hSizeClass == .regular ? 12 : 8) {
            // Tap gesture isolated to text only
            VStack(alignment: .leading, spacing: 4) {
                Text(waypoint.label)
                    .font(.system(size: hSizeClass == .regular ? 16 : 14, weight: .semibold))
                    .foregroundColor(.white)
                    .lineLimit(2)
                if let d = distance {
                    Text(formatDistance(d))
                        .font(.system(size: hSizeClass == .regular ? 14 : 12))
                        .foregroundColor(.white.opacity(0.7))
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .contentShape(Rectangle())
            .onTapGesture(perform: onTap)

            Button(action: onAR) {
                Image(systemName: "viewfinder")
                    .font(.system(size: hSizeClass == .regular ? 24 : 20))
                    .foregroundColor(.cyan)
                    .padding(4)
            }
            .buttonStyle(BorderlessButtonStyle())

            Button(action: onDelete) {
                Image(systemName: "trash")
                    .font(.system(size: hSizeClass == .regular ? 16 : 14))
                    .foregroundColor(.red.opacity(0.9))
                    .padding(4)
            }
            .buttonStyle(BorderlessButtonStyle())
        }
        .padding(hSizeClass == .regular ? 14 : 10)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(isSelected ? Color.blue.opacity(0.3) : Color.white.opacity(0.1))
                .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(.white.opacity(0.15), lineWidth: 1))
        )
        .frame(width: hSizeClass == .regular ? nil : 180)
    }

    private func formatDistance(_ meters: CLLocationDistance) -> String {
        if meters < 1000 { return String(format: "%.0f m", meters) }
        return String(format: "%.1f km", meters / 1000)
    }
}
// MARK: - AR Wayfinding (camera + direction arrow to waypoint)

struct ARWayfindingSheet: View {
    let waypoint: SavedWaypoint
    @ObservedObject var locationManager: LocationManager
    let onDismiss: () -> Void
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            ARWayfindingView(waypoint: waypoint, heading: locationManager.trueHeading, userLocation: locationManager.userLocation)
                .ignoresSafeArea()
            VStack {
                HStack {
                    Spacer()
                    Button("Done") {
                        onDismiss()
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                }
                Spacer()
                if let dist = locationManager.distance(to: waypoint), locationManager.bearing(to: waypoint) != nil {
                    Text("\(formatDistance(dist)) • Point phone toward the arrow")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.9))
                        .padding(.bottom, 32)
                }
            }
        }
        .onAppear {
            locationManager.startUpdating()
        }
    }
    
    private func formatDistance(_ meters: CLLocationDistance) -> String {
        if meters < 1000 { return String(format: "%.0f m away", meters) }
        return String(format: "%.1f km away", meters / 1000)
    }
}

struct ARWayfindingView: UIViewRepresentable {
    let waypoint: SavedWaypoint
    let heading: CLLocationDirection
    let userLocation: CLLocation?
    
    func makeUIView(context: Context) -> ARSCNView {
        let view = ARSCNView()
        view.session.run(ARWorldTrackingConfiguration())
        view.autoenablesDefaultLighting = true
        view.delegate = context.coordinator
        context.coordinator.sceneView = view
        context.coordinator.createDirectionNode()
        return view
    }
    
    func updateUIView(_ view: ARSCNView, context: Context) {
        context.coordinator.updateDirection(heading: heading, userLocation: userLocation, waypoint: waypoint)
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(waypoint: waypoint)
    }
    
    @MainActor
    final class Coordinator: NSObject, ARSCNViewDelegate {
        let waypoint: SavedWaypoint
        weak var sceneView: ARSCNView?
        var directionNode: SCNNode?
        private let distanceInFront: Float = 2.0
        
        init(waypoint: SavedWaypoint) {
            self.waypoint = waypoint
        }
        
        func createDirectionNode() {
            let arrow = SCNNode()
            let cone = SCNCone(topRadius: 0, bottomRadius: 0.2, height: 0.6)
            cone.radialSegmentCount = 8
            cone.firstMaterial?.diffuse.contents = UIColor.systemGreen
            cone.firstMaterial?.emission.contents = UIColor.systemGreen.withAlphaComponent(0.6)
            arrow.geometry = cone
            arrow.name = "directionArrow"
            arrow.opacity = 0.95
            // Cone axis is Y by default; rotate so it points along -Z (forward from camera)
            arrow.eulerAngles.x = -Float.pi / 2
            directionNode = arrow
        }
        
        func updateDirection(heading: CLLocationDirection, userLocation: CLLocation?, waypoint: SavedWaypoint) {
            guard let camera = sceneView?.pointOfView, let arrow = directionNode else { return }
            // Attach arrow to camera so it's always in front of the user
            if arrow.parent != camera {
                arrow.removeFromParentNode()
                arrow.position = SCNVector3(0, 0, -distanceInFront)
                camera.addChildNode(arrow)
            }
            guard let user = userLocation else { return }
            let bearingDeg = bearing(from: user.coordinate, to: waypoint.coordinate)
            let angleDeg = bearingDeg - heading
            arrow.eulerAngles.y = Float(angleDeg * .pi / 180)
        }
        
        private func bearing(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDirection {
            let dLon = (to.longitude - from.longitude) * .pi / 180
            let lat1 = from.latitude * .pi / 180
            let lat2 = to.latitude * .pi / 180
            let y = sin(dLon) * cos(lat2)
            let x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
            var b = atan2(y, x) * 180 / .pi
            if b < 0 { b += 360 }
            return b
        }
    }
}
